// Laboratorio 3 - SQRT por Newton-Raphson (raiz reciproca)
// Prototipo en punto fijo Q7.8, preparado para comparar con LC-3.
// Alcance de este prototipo: 4 <= x <= 16, x > 0.
// Q7.8: 1 bit de signo, 7 bits enteros, 8 bits fraccionarios.
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>

constexpr std::int32_t ESCALA = 256; // 2^8

// Multiplica dos valores Q7.8 positivos y vuelve a Q7.8.
// int32_t evita el desbordamiento del producto intermedio de 16 bits.
std::int16_t multiplicar_q(std::int16_t a, std::int16_t b) {
    if (a < 0 || b < 0) {
        throw std::invalid_argument("Este prototipo trabaja con operandos no negativos.");
    }

    const std::int32_t producto = static_cast<std::int32_t>(a) * b;
    const std::int32_t ajustado = producto / ESCALA; // trunca hacia cero

    if (ajustado > std::numeric_limits<std::int16_t>::max()) {
        throw std::overflow_error("Resultado fuera de 16 bits con signo.");
    }
    return static_cast<std::int16_t>(ajustado);
}

int main() {
    // 9.0 en Q7.8: 9 * 256 = 2304 = x0900.
    constexpr std::int16_t x = 2304;
    constexpr int iteraciones = 6;

    if (x < 4 * ESCALA || x > 16 * ESCALA) {
        std::cerr << "El prototipo requiere 4 <= x <= 16.\n";
        return 1;
    }

    // Semilla y=0.25: 0.25 * 256 = 64 = x0040.
    std::int16_t y = 64;
    constexpr std::int16_t TRES_Q = 3 * ESCALA;

    std::cout << std::fixed << std::setprecision(9);
    std::cout << "SQRT Newton-Raphson en Q7.8\n";

    for (int i = 0; i < iteraciones; ++i) {
        const std::int16_t y2 = multiplicar_q(y, y);
        const std::int16_t xy2 = multiplicar_q(x, y2);
        const std::int16_t factor = TRES_Q - xy2;
        const std::int16_t producto = multiplicar_q(factor, y);
        y = producto / 2;

        const std::int16_t raiz_q = multiplicar_q(x, y);
        std::cout << "Iteracion " << (i + 1)
                  << " | y_Q = " << y
                  << " | sqrt_Q = " << raiz_q
                  << " | sqrt(x) ~= "
                  << (static_cast<double>(raiz_q) / ESCALA) << '\n';
    }

    const std::int16_t raiz_q = multiplicar_q(x, y);
    std::cout << "\nResultado Q7.8 (entero): " << raiz_q << '\n';
    std::cout << "Resultado decimal: "
              << (static_cast<double>(raiz_q) / ESCALA) << '\n';
    return 0;
}
