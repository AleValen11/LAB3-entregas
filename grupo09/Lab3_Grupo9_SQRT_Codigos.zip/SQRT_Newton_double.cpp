// Laboratorio 3 - SQRT por Newton-Raphson (raiz reciproca)
// Version inicial para estudiar el algoritmo, con numeros reales (double).
#include <cmath>
#include <iomanip>
#include <iostream>

int main() {
    constexpr double x = 9.0;
    constexpr int iteraciones = 6;

    if (x <= 0.0) {
        std::cerr << "Esta version requiere x > 0.\n";
        return 1;
    }

    // Para este ejemplo x=9; 1/sqrt(9) es aproximadamente 0.3333.
    // Una semilla y=0.25 permite converger para este caso.
    double y = 0.25;

    std::cout << std::fixed << std::setprecision(9);
    std::cout << "SQRT Newton-Raphson con double\n";

    for (int i = 0; i < iteraciones; ++i) {
        const double y2 = y * y;
        const double xy2 = x * y2;
        const double factor = 3.0 - xy2;
        const double siguiente = (y * factor) / 2.0;

        y = siguiente;
        const double raiz_aproximada = x * y;
        std::cout << "Iteracion " << (i + 1)
                  << " | y = " << y
                  << " | sqrt(x) ~= " << raiz_aproximada << '\n';
    }

    const double raiz_aproximada = x * y;
    std::cout << "Resultado: " << raiz_aproximada << '\n';
    std::cout << "Referencia std::sqrt: " << std::sqrt(x) << '\n';
    return 0;
}
