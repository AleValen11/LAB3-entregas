; LABORATORIO 3 - SQRT por Newton-Raphson reciproco
; ISA LC-3 ORIGINAL (16 bits, sin instruccion MUL ni SHIFT)
; FORMATO: Q7.8 (factor de escala 256)
;
; PROTOTIPO PARA 4 <= x <= 16, con x positivo.
; x = 9.0   -> 2304 = x0900
; y0 = 0.25 ->   64 = x0040
; Tras 6 iteraciones: y_Q = 85, RAIZ_Q = 765
; Resultado decimal aproximado: 765 / 256 = 2.98828125
;
; El procedimiento MULQ espera:
;   R0 = a (Q7.8 no negativo)
;   R1 = b (Q7.8, 0 <= b <= 128)
; Devuelve:
;   R0 = floor(a*b/256) (Q7.8)
; Usa R2-R5 y conserva R6 y R7. No es multiplicador universal.
; Precondiciones de este ejemplo: los productos parciales entran
; en un entero con signo de 16 bits, sin desbordamiento.
;
        .ORIG x3000

        LD   R6, NITER
ITERAR  LD   R0, Y
        LD   R1, Y
        JSR  MULQ              ; y2 = y*y / 256
        ST   R0, Y2

        LD   R0, X
        LD   R1, Y2
        JSR  MULQ              ; xy2 = x*y2 / 256
        ST   R0, XY2

        LD   R0, TRES_Q        ; 3.0 en Q7.8
        LD   R1, XY2
        NOT  R1, R1
        ADD  R1, R1, #1        ; R1 = -xy2
        ADD  R0, R0, R1        ; factor = 3 - xy2
        ST   R0, FACTOR

        ; Importante: el segundo operando debe ser y (<= 128)
        LD   R1, Y
        JSR  MULQ              ; producto = factor*y / 256

        ; y_siguiente = floor(producto/2)
        AND  R1, R1, #0
MITAD   ADD  R2, R0, #-2
        BRn  MITAD_FIN
        ADD  R0, R2, #0
        ADD  R1, R1, #1
        BRnzp MITAD
MITAD_FIN  ST   R1, Y

        ADD  R6, R6, #-1
        BRp  ITERAR

        ; sqrt(x) = x*y, tambien en Q7.8
        LD   R0, X
        LD   R1, Y
        JSR  MULQ
        ST   R0, RAIZ_Q
        HALT

; -------------------------------------------------------------
; MULQ(a,b) = floor(a*b/256)
; Se aprovecha: a = 256*alto + bajo (0 <= bajo < 256).
; Entonces floor(a*b/256) = alto*b + floor(bajo*b/256).
; Asi evitamos el producto completo de 32 bits para el rango
; restringido de este ejercicio. No se usan instrucciones extra.
; -------------------------------------------------------------
MULQ    AND  R2, R2, #0       ; alto = 0
        ADD  R3, R0, #0       ; bajo = a
        LD   R4, MENOS256

SEPARAR ADD  R5, R3, R4       ; resta 256
        BRn  SEP_FIN
        ADD  R3, R5, #0
        ADD  R2, R2, #1
        BRnzp SEPARAR
; PARTE1 = alto * b (sumas sucesivas)
SEP_FIN  AND  R5, R5, #0
        ADD  R4, R2, #0
        BRz  ALTO_FIN
MULT_ALTO  ADD  R5, R5, R1
        ADD  R4, R4, #-1
        BRp  MULT_ALTO
ALTO_FIN  ST   R5, PARTE1

        ; PARTE2 = bajo * b (valor <= 255*128 = 32640)
        AND  R5, R5, #0
        ADD  R4, R1, #0
        BRz  BAJO_FIN
MULT_BAJO  ADD  R5, R5, R3
        ADD  R4, R4, #-1
        BRp  MULT_BAJO
; PARTE2 / 256 con division entera por restas
BAJO_FIN  AND  R2, R2, #0
        LD   R4, MENOS256
DIV256  ADD  R3, R5, R4
        BRn  DIV_FIN
        ADD  R5, R3, #0
        ADD  R2, R2, #1
        BRnzp DIV256
DIV_FIN  LD   R0, PARTE1
        ADD  R0, R0, R2
        RET

; Constantes y variables de datos
X       .FILL #2304           ; 9.0 en Q7.8
Y       .FILL #64             ; 0.25 en Q7.8
NITER   .FILL #6
TRES_Q  .FILL #768            ; 3.0 en Q7.8
MENOS256 .FILL #-256
Y2      .BLKW 1
XY2     .BLKW 1
FACTOR  .BLKW 1
PARTE1  .BLKW 1
RAIZ_Q  .BLKW 1               ; resultado final esperado: #765
        .END
